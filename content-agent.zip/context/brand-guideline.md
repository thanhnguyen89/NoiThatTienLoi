# Brand Guideline — Forme

## Tổng quan thương hiệu
- **Tên:** Forme
- **Tagline:** *Designed for how you live.*
- **Định vị:** Nội thất cao cấp tối giản cho không gian sống hiện đại
- **Sản phẩm:** Sofa và bàn cao cấp
- **Thị trường:** Việt Nam, tập trung TP.HCM và Hà Nội
- **Phân khúc giá:** Premium (sofa từ 50 triệu, bàn từ 20 triệu)

## Triết lý thương hiệu
Forme tin rằng một không gian sống đẳng cấp không cần phải phức tạp. Mỗi sản phẩm được thiết kế để tồn tại lâu dài — về cả chất lượng lẫn thẩm mỹ. Ít hơn, nhưng tốt hơn.

## Tone of Voice
**Là:** Tự tin. Tinh tế. Không cần chứng minh. Nói ít, nói đúng.
**Không là:** Hào nhoáng, khoa trương, dùng nhiều tính từ sáo rỗng.

**Ví dụ đúng:**
> "Sofa Arc. Thiết kế cho những buổi tối không cần giải thích."

**Ví dụ sai:**
> "Siêu phẩm sofa cao cấp sang trọng đẳng cấp quốc tế!!!"

## Màu sắc thương hiệu
| Màu | Mã | Dùng cho |
|---|---|---|
| Warm White | #F5F0E8 | Nền chính, background ảnh |
| Warm Beige | #C9A882 | Màu chủ đạo, tường, accent lớn |
| Cream | #EDE0CC | Màu phụ, vải sofa |
| Caramel | #A0724A | Chi tiết gỗ, da thuộc, highlight |
| Dark Brown | #3D2B1F | Typography chính, chân bàn |

## Typography
- **Tiêu đề:** Serif thanh mảnh (Cormorant Garamond, Playfair Display)
- **Body:** Sans-serif tối giản (Inter, DM Sans)

## Phong cách hình ảnh
- Tông màu ấm: mocha brown tường, cream vải, walnut sản phẩm, oak sàn
- Ánh sáng tự nhiên từ cửa sổ lớn — bóng đổ hình học sharp
- Sản phẩm chiếm 40-50% frame, phần còn lại là khoảng thở
- Không có người trong ảnh
- Không filter đậm, không oversaturate
