/**
 * Content Agent — Web UI Server
 * Pipeline 8 bước: Research → Outline → Content → SEO → QC → Thumbnail + Section Images (song song) → Publish
 * Gemini API + Mock fallback
 */

import 'dotenv/config';
import express from 'express';
import { GoogleGenerativeAI } from '@google/generative-ai';
import axios from 'axios';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// Gemini
let geminiAvailable = !!process.env.GEMINI_API_KEY;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Brand data — đọc từ context/
const contextDir = path.join(__dirname, '..', 'context');
function loadContext(name) {
  const file = path.join(contextDir, name);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf-8') : '';
}
const brandData = {
  brandGuideline: loadContext('brand-guideline.md'),
  customerPersona: loadContext('customer-persona.md'),
  marketingChannels: loadContext('marketing-channels.md'),
  productCatalog: loadContext('product-catalog.md'),
};

// SOP + Data
const sopDir = path.join(__dirname, '..', 'sop');
const dataDir = path.join(__dirname, '..', 'data');
function loadSop(name) {
  const file = path.join(sopDir, name);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf-8') : '';
}
function loadData(name) {
  const file = path.join(dataDir, name);
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf-8') : '';
}
const contentSop = loadSop('content-sop.md');
const researchSop = loadSop('research-sop.md');
const performanceData = loadData('performance-latest.md');

// Agent prompts
const agentsDir = path.join(__dirname, '..', '.claude', 'agents');
function loadAgentPrompt(name) {
  const file = path.join(agentsDir, `${name}.md`);
  if (!fs.existsSync(file)) return '';
  return fs.readFileSync(file, 'utf-8').replace(/^---[\s\S]*?---\n/, '');
}

// CLAUDE.md — Hiến pháp dự án, inject vào mọi agent call
const claudeMdPath = path.join(__dirname, '..', 'CLAUDE.md');
const claudeMd = fs.existsSync(claudeMdPath) ? fs.readFileSync(claudeMdPath, 'utf-8') : '';
console.log(claudeMd ? '📜 CLAUDE.md loaded' : '⚠️ CLAUDE.md not found');

// ============================================
// API
// ============================================
app.get('/api/brand', (req, res) => res.json({
  ...brandData,
  contentSop,
  researchSop,
  performanceData,
}));
app.get('/api/status', (req, res) => res.json({ geminiAvailable }));
app.get('/api/products', (req, res) => {
  res.json([
    { id: 'lento', name: 'Lento — Sofa Góc L', price: '85.000.000 VNĐ', category: 'Ghế' },
    { id: 'cleo', name: 'Cleo — Ghế Đơn', price: '42.000.000 VNĐ', category: 'Ghế' },
    { id: 'noir', name: 'Noir — Bàn Ăn', price: '48.000.000 VNĐ', category: 'Bàn' },
    { id: 'arc', name: 'Arc — Bàn Oval', price: '32.000.000 VNĐ', category: 'Bàn' },
  ]);
});

// ============================================
// PIPELINE SSE — 6 bước
// ============================================
app.get('/api/pipeline/stream', async (req, res) => {
  const keyword = req.query.keyword;
  if (!keyword) return res.status(400).json({ error: 'Thiếu từ khóa' });

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
  });

  const send = (step, status, data) => {
    res.write(`data: ${JSON.stringify({ step, status, data })}\n\n`);
  };

  const brandContext = [
    '=== CONTEXT: BRAND ===', brandData.brandGuideline,
    '=== CONTEXT: CUSTOMER ===', brandData.customerPersona,
    '=== CONTEXT: PRODUCTS ===', brandData.productCatalog,
    '=== CONTEXT: CHANNELS ===', brandData.marketingChannels,
    '=== SOP: CONTENT ===', contentSop,
    '=== DATA: PERFORMANCE ===', performanceData,
  ].join('\n\n');

  try {
    // ── STEP 1: RESEARCH ──
    send('research', 'running', null);
    const research = await callGemini(
      loadAgentPrompt('researcher') || `Bạn là Research Analyst chuyên phân tích nội dung tiếng Việt.
Nhiệm vụ: phân tích từ khóa, xác định search intent, đối tượng mục tiêu, keyword phụ, câu hỏi cần trả lời, key points.
Output BẮT BUỘC là JSON hợp lệ.`,
      `${brandContext}\n\n---\nTừ khóa: "${keyword}"\n\nPhân tích và trả về JSON với format:
{
  "agent": "research",
  "status": "success",
  "keyword": "${keyword}",
  "search_intent": "informational | navigational | transactional | commercial",
  "target_audience": "mô tả đối tượng đọc bài",
  "secondary_keywords": ["keyword phụ 1", "keyword phụ 2", ...],
  "questions_to_answer": ["câu hỏi 1", "câu hỏi 2", ...],
  "key_points": ["điểm chính 1", "điểm chính 2", ...],
  "recommended_word_count": 2000,
  "content_gaps": ["gap 1", "gap 2"]
}`,
      () => mockResearch(keyword)
    );
    send('research', 'done', research);

    // ── STEP 2: OUTLINE ──
    send('outline', 'running', null);
    const outline = await callGemini(
      loadAgentPrompt('architect') || `Bạn là Content Strategist chuyên xây cấu trúc bài viết SEO tiếng Việt.
Nhận research data → tạo outline chi tiết với heading H2/H3, key points từng phần, meta description.
Output BẮT BUỘC là JSON hợp lệ.`,
      `${brandContext}\n\n---\nResearch data:\n${JSON.stringify(research, null, 2)}\n\nTạo outline JSON:
{
  "agent": "outline",
  "status": "success",
  "title": "tiêu đề bài viết đề xuất",
  "meta_description": "meta description cho SEO (150-160 ký tự)",
  "slug": "url-slug",
  "estimated_total_words": 2000,
  "seo_keywords": ["keyword cần tích hợp"],
  "sections": [
    {
      "h2": "Heading H2",
      "h3s": ["H3 con nếu có"],
      "key_points": ["điểm chính section này"],
      "estimated_words": 300
    }
  ]
}`,
      () => mockOutline(keyword, research)
    );
    send('outline', 'done', outline);

    // ── STEP 3: CONTENT ──
    send('content', 'running', null);
    const content = await callGemini(
      loadAgentPrompt('writer') || `Bạn là Content Writer người Việt 8 năm kinh nghiệm.
Viết bài HTML hoàn chỉnh theo outline. Viết như người thật, không như robot.
Tích hợp keyword tự nhiên. Output HTML trong JSON.
KHÔNG dùng: "quan trọng", "hiệu quả", "bên cạnh đó", "trong thế giới hiện đại", "hy vọng bài viết".
Câu ngắn xen câu dài. Đoạn văn tối đa 80 từ.`,
      `${brandContext}\n\n---\nOutline:\n${JSON.stringify(outline, null, 2)}\n\nResearch:\n${JSON.stringify(research, null, 2)}\n\nViết bài HTML và trả về JSON:
{
  "agent": "content",
  "status": "success",
  "word_count": 0,
  "html_content": "<article>...</article>",
  "seo_keywords_used": ["keyword đã dùng"]
}`,
      () => mockContent(keyword, outline)
    );
    send('content', 'done', content);

    // ── STEP 4: SEO OPTIMIZE ──
    send('seo', 'running', null);
    const seo = await callGemini(
      loadAgentPrompt('seo-specialist') || `Bạn là SEO Specialist 10 năm kinh nghiệm thị trường Việt Nam.
Nhiệm vụ: tối ưu kỹ thuật SEO cho bài viết — KHÔNG viết lại nội dung, KHÔNG thay đổi giọng văn.
Keyword density mục tiêu: 1.0–1.5%. Nếu chèn keyword làm câu gượng → BỎ QUA.
Output BẮT BUỘC là JSON.`,
      `${brandContext}\n\n---\nBài viết HTML:\n${content?.html_content || ''}\n\nKeyword data:\n${JSON.stringify({
        primary_keyword: keyword,
        secondary_keywords: research?.secondary_keywords || [],
        seo_keywords: outline?.seo_keywords || [],
      }, null, 2)}\n\nOutline:\n${JSON.stringify(outline, null, 2)}\n\nTối ưu SEO và trả về JSON:
{
  "agent": "seo",
  "status": "success",
  "seo_score": 0,
  "title_tag": "title tag tối ưu (50-60 ký tự)",
  "meta_description": "meta description (150-160 ký tự)",
  "slug": "url-slug",
  "keyword_density": "x.x%",
  "keyword_in_first_100_words": true,
  "issues_fixed": [{"issue": "", "action": ""}],
  "issues_remaining": [{"level": "critical|warning", "issue": ""}],
  "optimized_html": "<article>bài đã tối ưu</article>"
}`,
      () => mockSEO(keyword, content)
    );
    send('seo', 'done', seo);

    // ── STEP 5: QC / HUMANIZE ──
    send('qc', 'running', null);
    const qc = await callGemini(
      loadAgentPrompt('editor-qc') || `Bạn là Biên tập viên Senior 12 năm kinh nghiệm tại các tòa soạn lớn Việt Nam.
Nhiệm vụ: biên tập để bài đọc như người thật viết. Xóa dấu vết AI.
Từ cấm phải xóa: "quan trọng", "hiệu quả", "tuy nhiên", "bên cạnh đó", "đáng kể", "trong thế giới hiện đại", "không thể phủ nhận", "toàn diện", "hy vọng bài viết", "thông tin hữu ích".
Chấm Humanness Score /100. Decision: PUBLISH (≥76) | REVIEW (60-75) | REWRITE (<60).
Output BẮT BUỘC là JSON.`,
      `${brandContext}\n\n---\nBài viết đã tối ưu SEO:\n${seo?.optimized_html || content?.html_content || ''}\n\nBiên tập, humanize, chấm điểm. Trả về JSON:
{
  "agent": "qc",
  "status": "success",
  "humanness_score": 0,
  "score_breakdown": {"language_natural": 0, "structure": 0, "eeat_signals": 0, "engagement": 0},
  "decision": "PUBLISH | REVIEW | REWRITE",
  "banned_words_found": ["từ cấm tìm thấy"],
  "changes_made": ["thay đổi 1", "thay đổi 2"],
  "final_html": "<article>bài đã humanize</article>"
}`,
      () => mockQC(keyword)
    );
    send('qc', 'done', qc);

    // ── STEP 6 + 7: THUMBNAIL + SECTION IMAGES (song song) ──
    send('thumbnail', 'running', null);
    send('sectionImages', 'running', null);

    const [thumbnail, sectionImages] = await Promise.all([
      // Thumbnail
      (async () => {
        const result = {
          agent: 'thumbnail', status: 'success', _source: 'mock',
          image: {
            url: `https://placehold.co/1200x630/F5F0E8/3D2B1F?text=${encodeURIComponent(keyword)}`,
            alt_text: `${keyword} - Forme`,
            width: 1200, height: 630,
            prompt: `Premium minimalist ${keyword}, warm-toned living room, natural light, editorial photography, Forme brand style`,
          },
          notes: 'Mock — cần tích hợp Gemini Imagen / DALL-E / OpenRouter',
        };
        await sleep(500);
        return result;
      })(),
      // Section Images
      (async () => {
        const sections = outline?.sections || [];
        const maxImages = Math.min(sections.length, 3);
        const result = {
          agent: 'section-images', status: 'success', _source: 'mock',
          images: sections.slice(0, maxImages).map((s, i) => ({
            section_h2: s.h2,
            url: `https://placehold.co/800x450/EDE0CC/3D2B1F?text=Section+${i + 1}`,
            alt_text: s.h2,
            width: 800, height: 450,
            prompt: `Evocative cinematic photo for "${s.h2}", warm atmospheric lighting, no text overlay`,
            style: 'evocative/cinematic',
          })),
          notes: 'Mock — ảnh evocative/cinematic',
        };
        await sleep(500);
        return result;
      })(),
    ]);

    send('thumbnail', 'done', thumbnail);
    send('sectionImages', 'done', sectionImages);

    // ── STEP 8: PUBLISH ──
    send('publish', 'running', null);
    const slug = keyword.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const publish = {
      agent: 'publisher', status: 'pending_approval',
      post_url: `https://forme.vn/${slug}`,
      report: {
        title: seo?.title_tag || outline?.title || keyword,
        slug: seo?.slug || slug,
        meta_description: seo?.meta_description || outline?.meta_description || '',
        word_count: content?.word_count || 0,
        seo_score: seo?.seo_score || 0,
        humanness_score: qc?.humanness_score || 0,
        decision: qc?.decision || 'REVIEW',
        images_count: 1 + sectionImages.images.length,
        seo_keywords: outline?.seo_keywords || [],
      },
    };
    await sleep(300);
    send('publish', 'done', publish);

    send('complete', 'done', { message: 'Pipeline hoàn thành' });
  } catch (err) {
    console.error('Pipeline error:', err);
    send('error', 'failed', { message: err.message });
  }
  res.end();
});

// ============================================
// GEMINI CALLER
// ============================================
async function callGemini(systemPrompt, userMessage, mockFn) {
  if (!geminiAvailable) {
    console.log(`[mock] Gemini unavailable`);
    await sleep(600 + Math.random() * 800);
    return mockFn();
  }
  try {
    // Inject CLAUDE.md (hiến pháp) + agent prompt
    const fullPrompt = [
      claudeMd ? `=== HIẾN PHÁP DỰ ÁN (CLAUDE.md) ===\n${claudeMd}\n=== HẾT HIẾN PHÁP ===` : '',
      systemPrompt,
    ].filter(Boolean).join('\n\n');

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || 'gemini-2.0-flash'}:generateContent?key=${process.env.GEMINI_API_KEY}`;

    const { data } = await axios.post(apiUrl, {
      contents: [{ role: 'user', parts: [{ text: `${fullPrompt}\n\n---\n\n${userMessage}` }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: 8192, responseMimeType: 'application/json' },
    }, { timeout: 60000 });

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('No JSON in response');
    const parsed = JSON.parse(jsonMatch[0]);
    parsed._source = 'gemini';
    console.log(`✅ Gemini OK`);
    return parsed;
  } catch (err) {
    const msg = err.response?.data?.error?.message || err.message;
    console.warn(`⚠️ Gemini failed: ${msg} → mock`);
    return mockFn();
  }
}

// ============================================
// MOCK DATA
// ============================================

function mockResearch(keyword) {
  return {
    agent: 'research', status: 'success', _source: 'mock',
    keyword,
    search_intent: 'commercial',
    target_audience: 'Doanh nhân, chuyên gia cao cấp 40-55 tuổi tại TP.HCM và Hà Nội, đang tìm nội thất premium cho không gian sống',
    secondary_keywords: [`${keyword} cao cấp`, `mua ${keyword}`, `${keyword} đẹp`, `${keyword} giá tốt`],
    questions_to_answer: [`${keyword} giá bao nhiêu?`, `Nên mua ${keyword} ở đâu?`, `${keyword} nào tốt nhất?`, `Chất liệu nào bền nhất?`],
    key_points: ['So sánh chất liệu', 'Kích thước theo diện tích', 'Mức giá thị trường VN', 'Kinh nghiệm chọn mua'],
    recommended_word_count: 2200,
    content_gaps: ['Chưa ai viết về trải nghiệm thực tế tại showroom', 'Thiếu so sánh chất liệu chi tiết'],
  };
}

function mockOutline(keyword, research) {
  return {
    agent: 'outline', status: 'success', _source: 'mock',
    title: `${keyword}: Hướng Dẫn Chọn Đúng Từ Chuyên Gia Nội Thất`,
    meta_description: `Tìm hiểu cách chọn ${keyword} phù hợp không gian sống. So sánh chất liệu, giá thực tế, lời khuyên từ interior designer.`,
    slug: keyword.toLowerCase().replace(/\s+/g, '-'),
    estimated_total_words: 2200,
    seo_keywords: [keyword, ...(research?.secondary_keywords || []).slice(0, 3)],
    sections: [
      { h2: `Tại sao chọn ${keyword} không đơn giản`, h3s: [], key_points: ['Quá nhiều lựa chọn', 'Ảnh đẹp ≠ chất lượng tốt'], estimated_words: 300 },
      { h2: 'So sánh chất liệu: Da thật vs Vải vs Da tổng hợp', h3s: ['Da bò full-grain', 'Vải linen cao cấp', 'Da tổng hợp PU'], key_points: ['Bảng so sánh', 'Ưu nhược điểm', 'Giá'], estimated_words: 500 },
      { h2: 'Kích thước phù hợp theo diện tích phòng', h3s: [], key_points: ['Quy tắc 40%', 'Đo phòng trước'], estimated_words: 400 },
      { h2: 'Mức giá thực tế tại Việt Nam 2024', h3s: [], key_points: ['4 phân khúc giá', 'Tỷ lệ chất lượng/giá'], estimated_words: 400 },
      { h2: 'Lời khuyên từ interior designer', h3s: [], key_points: ['Ngồi thử 15 phút', 'Mang gối tựa lưng'], estimated_words: 300 },
    ],
  };
}

function mockContent(keyword, outline) {
  return {
    agent: 'content', status: 'success', _source: 'mock',
    word_count: 2180,
    html_content: `<article>
<h1>${outline?.title || keyword}</h1>
<p>7 giờ tối. Bạn ngồi xuống chiếc ghế cũ sau một ngày dài. Lưng đau. Đệm lún. Và bạn tự hỏi: đã đến lúc thay chưa?</p>
<p>Câu trả lời ngắn: rồi. Câu trả lời dài hơn nằm trong bài viết này — không phải để bán hàng, mà để bạn không mất 50 triệu vào thứ sai.</p>

<h2>Tại sao chọn ${keyword} không đơn giản</h2>
<p>Thị trường nội thất Việt Nam có hàng trăm thương hiệu. Giá từ 5 triệu đến 500 triệu. Nhìn ảnh thì chiếc nào cũng đẹp. Nhưng ngồi thử 30 phút — khác biệt lộ rõ.</p>
<p>Vấn đề không phải "chiếc nào đẹp nhất" mà là "chiếc nào phù hợp không gian của bạn nhất".</p>

<h2>So sánh chất liệu: Da thật vs Vải vs Da tổng hợp</h2>
<table>
<thead><tr><th>Chất liệu</th><th>Ưu điểm</th><th>Nhược điểm</th><th>Giá TB</th></tr></thead>
<tbody>
<tr><td>Da bò full-grain</td><td>Bền 15-20 năm, đẹp theo thời gian</td><td>Giá cao, cần bảo dưỡng</td><td>60-120 triệu</td></tr>
<tr><td>Vải linen cao cấp</td><td>Thoáng mát, nhiều màu, dễ thay vỏ</td><td>Dễ bám bẩn hơn da</td><td>40-80 triệu</td></tr>
<tr><td>Da tổng hợp PU</td><td>Giá rẻ, dễ vệ sinh</td><td>Bong tróc sau 3-5 năm</td><td>15-35 triệu</td></tr>
</tbody>
</table>

<h2>Kích thước phù hợp theo diện tích phòng</h2>
<p>Phòng 20m²: sofa 2 chỗ. Phòng 30m²: sofa 3 chỗ hoặc L nhỏ. Phòng 40m²+: sofa góc L lớn.</p>
<p>Quy tắc vàng: sofa không chiếm quá 40% diện tích sàn phòng khách.</p>

<h2>Mức giá thực tế tại Việt Nam 2024</h2>
<table>
<thead><tr><th>Phân khúc</th><th>Khoảng giá</th><th>Đặc điểm</th></tr></thead>
<tbody>
<tr><td>Phổ thông</td><td>5-15 triệu</td><td>Khung gỗ ép, đệm mỏng</td></tr>
<tr><td>Trung cấp</td><td>15-40 triệu</td><td>Khung gỗ tự nhiên, đệm tốt</td></tr>
<tr><td>Cao cấp</td><td>40-100 triệu</td><td>Chất liệu nhập, thiết kế riêng</td></tr>
<tr><td>Luxury</td><td>100 triệu+</td><td>Thương hiệu, handmade</td></tr>
</tbody>
</table>

<h2>Lời khuyên từ interior designer</h2>
<p>"Đừng chọn sofa vì nó đẹp trên Instagram. Hãy ngồi thử ít nhất 15 phút. Nếu sau 15 phút bạn không muốn đứng dậy — đó là chiếc sofa đúng."</p>
<p>Thử áp dụng quy tắc 15 phút trong tuần này. Ghé một showroom, ngồi thử, và bạn sẽ biết ngay.</p>
</article>`,
    seo_keywords_used: [keyword, `${keyword} cao cấp`, 'chất liệu', 'nội thất'],
  };
}

function mockSEO(keyword, content) {
  return {
    agent: 'seo', status: 'success', _source: 'mock',
    seo_score: 87,
    title_tag: `${keyword}: Hướng Dẫn Chọn Đúng Từ Chuyên Gia | Forme`,
    meta_description: `Tìm hiểu cách chọn ${keyword} phù hợp không gian sống. So sánh chất liệu, giá thực tế 2024, lời khuyên từ interior designer.`,
    slug: keyword.toLowerCase().replace(/\s+/g, '-'),
    keyword_density: '1.3%',
    keyword_in_first_100_words: true,
    issues_fixed: [
      { issue: 'Thiếu keyword trong H2 đầu tiên', action: 'Đã thêm keyword tự nhiên' },
      { issue: 'Alt text ảnh trống', action: 'Đã thêm alt text có keyword' },
      { issue: 'Meta description quá ngắn', action: 'Đã viết lại 155 ký tự' },
    ],
    issues_remaining: [],
    optimized_html: content?.html_content || '',
  };
}

function mockQC(keyword) {
  return {
    agent: 'qc', status: 'success', _source: 'mock',
    humanness_score: 82,
    score_breakdown: { language_natural: 21, structure: 22, eeat_signals: 19, engagement: 20 },
    decision: 'PUBLISH',
    banned_words_found: ['quan trọng (1 lần)', 'hiệu quả (1 lần)'],
    changes_made: [
      'Viết lại mở bài — dùng tình huống cụ thể',
      'Xóa 2 từ cấm: "quan trọng", "hiệu quả"',
      'Thêm 4 câu ngắn 5-7 từ tại điểm nhấn',
      'Phá 1 bullet list thành đoạn văn',
      'Viết lại kết bài — CTA cụ thể: quy tắc 15 phút',
    ],
    final_html: '',
  };
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

app.listen(PORT, () => {
  console.log(`\n🚀 Content Agent UI: http://localhost:${PORT}`);
  console.log(`📡 Gemini: ${geminiAvailable ? 'Sẵn sàng (' + (process.env.GEMINI_MODEL || 'gemini-2.0-flash') + ')' : '❌ Mock data'}\n`);
});
